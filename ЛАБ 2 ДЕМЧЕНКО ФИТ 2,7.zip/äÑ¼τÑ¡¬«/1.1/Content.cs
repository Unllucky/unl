﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1._1
{
    class Content
      
    {
        public string con;
        public void show()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(con);
            Console.ForegroundColor = ConsoleColor.White;

        }

    }
}
